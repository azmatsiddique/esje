"""Credential prompting and environment variable resolution for esje."""

import getpass
import os
import sys
from typing import Any, Dict, Optional

from dotenv import load_dotenv

from esje.errors import ConnectionError

# Load environment variables from .env if present
load_dotenv()


def is_interactive() -> bool:
    """Check if execution environment is interactive (TTY or IPython)."""
    if sys.stdin and hasattr(sys.stdin, "isatty") and sys.stdin.isatty():
        return True

    # Check for IPython interactive shell presence
    try:
        from IPython import get_ipython

        ip = get_ipython()
        if ip is not None:
            return True
    except ImportError:
        pass

    return False


def resolve_mysql_credentials(
    host: Optional[str] = None,
    port: Optional[int] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    database: Optional[str] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve MySQL connection credentials from arguments, env vars, or interactive prompts.

    Args:
        host: Hostname or IP.
        port: Port number.
        user: Username.
        password: Password.
        database: Database name.
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: host, port, user, password, database.
    """
    env_host = os.getenv("ESJE_MYSQL_HOST") or os.getenv("MYSQL_HOST")
    env_port = os.getenv("ESJE_MYSQL_PORT") or os.getenv("MYSQL_PORT")
    env_user = os.getenv("ESJE_MYSQL_USER") or os.getenv("MYSQL_USER")
    env_password = os.getenv("ESJE_MYSQL_PASSWORD") or os.getenv("MYSQL_PASSWORD")
    env_database = os.getenv("ESJE_MYSQL_DATABASE") or os.getenv("MYSQL_DATABASE")

    # Resolve values with precedence: explicit arg -> env var -> interactive prompt
    resolved_host = host if host is not None else env_host
    resolved_port = port if port is not None else (int(env_port) if env_port else None)
    resolved_user = user if user is not None else env_user
    resolved_password = password if password is not None else env_password
    resolved_database = database if database is not None else env_database

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_host is None:
            host_input = input("Host [localhost]: ").strip()
            resolved_host = host_input if host_input else "localhost"

        if resolved_port is None:
            port_input = input("Port [3306]: ").strip()
            resolved_port = int(port_input) if port_input else 3306

        if resolved_user is None:
            resolved_user = input("Username: ").strip()

        if resolved_password is None:
            resolved_password = getpass.getpass("Password: ")

        if resolved_database is None:
            database_input = input("Database [optional]: ").strip()
            resolved_database = database_input if database_input else ""

    else:
        # Non-interactive fallback defaults
        if resolved_host is None:
            resolved_host = "localhost"
        if resolved_port is None:
            resolved_port = 3306
        if resolved_user is None:
            resolved_user = ""
        if resolved_password is None:
            resolved_password = ""
        if resolved_database is None:
            resolved_database = ""

    return {
        "host": resolved_host,
        "port": int(resolved_port),
        "user": resolved_user,
        "password": resolved_password,
        "database": resolved_database,
    }


def resolve_bigquery_credentials(
    project: Optional[str] = None,
    dataset: Optional[str] = None,
    credentials_path: Optional[str] = None,
    location: Optional[str] = None,
    auth_method: Optional[str] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve BigQuery connection credentials from arguments, env vars, or interactive prompts.

    Args:
        project: GCP Project ID.
        dataset: Default BigQuery dataset name.
        credentials_path: Path to Google Service Account JSON key file.
        location: BigQuery dataset location (e.g. 'US', 'EU').
        auth_method: One of 'browser', 'adc', or 'service_account'. Auto-detected if None.
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: project, dataset, credentials_path, location, auth_method.
    """
    env_project = (
        os.getenv("ESJE_BIGQUERY_PROJECT")
        or os.getenv("GCP_PROJECT")
        or os.getenv("GOOGLE_CLOUD_PROJECT")
        or os.getenv("BIGQUERY_PROJECT")
    )
    env_dataset = os.getenv("ESJE_BIGQUERY_DATASET") or os.getenv("BIGQUERY_DATASET")
    env_credentials_path = (
        os.getenv("ESJE_BIGQUERY_CREDENTIALS_PATH")
        or os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
    )
    env_location = os.getenv("ESJE_BIGQUERY_LOCATION") or os.getenv("BIGQUERY_LOCATION")
    env_auth_method = os.getenv("ESJE_BIGQUERY_AUTH_METHOD")

    resolved_project = project if project is not None else env_project
    resolved_dataset = dataset if dataset is not None else env_dataset
    resolved_credentials_path = (
        credentials_path if credentials_path is not None else env_credentials_path
    )
    resolved_location = location if location is not None else env_location
    resolved_auth_method = auth_method if auth_method is not None else env_auth_method

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    # Auto-determine auth_method if not specified:
    # - If a credentials path is available -> service_account
    # - If interactive -> browser (opens login in browser)
    # - Otherwise -> adc (gcloud ADC)
    if resolved_auth_method is None:
        if resolved_credentials_path:
            resolved_auth_method = "service_account"
        elif should_prompt:
            resolved_auth_method = "browser"
        else:
            resolved_auth_method = "adc"

    if should_prompt and resolved_auth_method != "browser":
        # Only prompt for project/dataset when not using browser login
        # (browser flow can auto-detect these from the token)
        if resolved_project is None:
            project_input = input("GCP Project ID: ").strip()
            resolved_project = project_input if project_input else ""

        if resolved_dataset is None:
            dataset_input = input("BigQuery Dataset [optional]: ").strip()
            resolved_dataset = dataset_input if dataset_input else ""

        if resolved_auth_method == "service_account" and resolved_credentials_path is None:
            cred_input = input("Service Account JSON Path: ").strip()
            resolved_credentials_path = cred_input if cred_input else None

    elif should_prompt and resolved_auth_method == "browser":
        # For browser login, only ask for project if we really need it
        if resolved_project is None:
            project_input = input("GCP Project ID [optional, press Enter to auto-detect]: ").strip()
            resolved_project = project_input if project_input else ""

    return {
        "project": resolved_project or "",
        "dataset": resolved_dataset or "",
        "credentials_path": resolved_credentials_path,
        "location": resolved_location,
        "auth_method": resolved_auth_method,
    }


def resolve_postgres_credentials(
    host: Optional[str] = None,
    port: Optional[int] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    database: Optional[str] = None,
    sslmode: Optional[str] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve PostgreSQL connection credentials from arguments, env vars, or interactive prompts.

    Args:
        host: Hostname or IP.
        port: Port number.
        user: Username.
        password: Password.
        database: Database name.
        sslmode: SSL connection mode (e.g. 'require', 'prefer', 'disable').
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: host, port, user, password, database, sslmode.
    """
    env_host = os.getenv("ESJE_POSTGRES_HOST") or os.getenv("POSTGRES_HOST") or os.getenv("PGHOST")
    env_port = os.getenv("ESJE_POSTGRES_PORT") or os.getenv("POSTGRES_PORT") or os.getenv("PGPORT")
    env_user = os.getenv("ESJE_POSTGRES_USER") or os.getenv("POSTGRES_USER") or os.getenv("PGUSER")
    env_password = os.getenv("ESJE_POSTGRES_PASSWORD") or os.getenv("POSTGRES_PASSWORD") or os.getenv("PGPASSWORD")
    env_database = os.getenv("ESJE_POSTGRES_DATABASE") or os.getenv("POSTGRES_DATABASE") or os.getenv("PGDATABASE")
    env_sslmode = os.getenv("ESJE_POSTGRES_SSLMODE") or os.getenv("PGSSLMODE")

    resolved_host = host if host is not None else env_host
    resolved_port = port if port is not None else (int(env_port) if env_port else None)
    resolved_user = user if user is not None else env_user
    resolved_password = password if password is not None else env_password
    resolved_database = database if database is not None else env_database
    resolved_sslmode = sslmode if sslmode is not None else env_sslmode

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_host is None:
            host_input = input("Host [localhost]: ").strip()
            resolved_host = host_input if host_input else "localhost"

        if resolved_port is None:
            port_input = input("Port [5432]: ").strip()
            resolved_port = int(port_input) if port_input else 5432

        if resolved_user is None:
            user_input = input("Username [postgres]: ").strip()
            resolved_user = user_input if user_input else "postgres"

        if resolved_password is None:
            resolved_password = getpass.getpass("Password: ")

        if resolved_database is None:
            database_input = input("Database [postgres]: ").strip()
            resolved_database = database_input if database_input else "postgres"

    else:
        # Non-interactive fallback defaults
        if resolved_host is None:
            resolved_host = "localhost"
        if resolved_port is None:
            resolved_port = 5432
        if resolved_user is None:
            resolved_user = "postgres"
        if resolved_password is None:
            resolved_password = ""
        if resolved_database is None:
            resolved_database = "postgres"

    return {
        "host": resolved_host,
        "port": int(resolved_port),
        "user": resolved_user,
        "password": resolved_password,
        "database": resolved_database,
        "sslmode": resolved_sslmode,
    }


def resolve_duckdb_credentials(
    database: Optional[str] = None,
    read_only: Optional[bool] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve DuckDB database path and settings from arguments, env vars, or interactive prompts.

    Args:
        database: Path to DuckDB file or ':memory:'.
        read_only: Whether to open in read-only mode.
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: database, read_only.
    """
    env_database = os.getenv("ESJE_DUCKDB_DATABASE") or os.getenv("DUCKDB_DATABASE")
    env_read_only = os.getenv("ESJE_DUCKDB_READ_ONLY")

    resolved_database = database if database is not None else env_database
    if read_only is not None:
        resolved_read_only = read_only
    elif env_read_only is not None:
        resolved_read_only = env_read_only.lower() in ("true", "1", "yes")
    else:
        resolved_read_only = False

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_database is None:
            db_input = input("Database path [:memory:]: ").strip()
            resolved_database = db_input if db_input else ":memory:"
    else:
        if resolved_database is None:
            resolved_database = ":memory:"

    return {
        "database": resolved_database,
        "read_only": resolved_read_only,
    }


def resolve_cockroachdb_credentials(
    host: Optional[str] = None,
    port: Optional[int] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    database: Optional[str] = None,
    sslmode: Optional[str] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve CockroachDB connection credentials from arguments, env vars, or interactive prompts.

    Args:
        host: Hostname or IP.
        port: Port number.
        user: Username.
        password: Password.
        database: Database name.
        sslmode: SSL connection mode (e.g. 'require', 'disable').
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: host, port, user, password, database, sslmode.
    """
    env_host = os.getenv("ESJE_COCKROACH_HOST") or os.getenv("COCKROACH_HOST")
    env_port = os.getenv("ESJE_COCKROACH_PORT") or os.getenv("COCKROACH_PORT")
    env_user = os.getenv("ESJE_COCKROACH_USER") or os.getenv("COCKROACH_USER")
    env_password = os.getenv("ESJE_COCKROACH_PASSWORD") or os.getenv("COCKROACH_PASSWORD")
    env_database = os.getenv("ESJE_COCKROACH_DATABASE") or os.getenv("COCKROACH_DATABASE")
    env_sslmode = os.getenv("ESJE_COCKROACH_SSLMODE") or os.getenv("COCKROACH_SSLMODE")

    resolved_host = host if host is not None else env_host
    resolved_port = port if port is not None else (int(env_port) if env_port else None)
    resolved_user = user if user is not None else env_user
    resolved_password = password if password is not None else env_password
    resolved_database = database if database is not None else env_database
    resolved_sslmode = sslmode if sslmode is not None else env_sslmode

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_host is None:
            host_input = input("Host [localhost]: ").strip()
            resolved_host = host_input if host_input else "localhost"

        if resolved_port is None:
            port_input = input("Port [26257]: ").strip()
            resolved_port = int(port_input) if port_input else 26257

        if resolved_user is None:
            user_input = input("Username [root]: ").strip()
            resolved_user = user_input if user_input else "root"

        if resolved_password is None:
            resolved_password = getpass.getpass("Password: ")

        if resolved_database is None:
            database_input = input("Database [defaultdb]: ").strip()
            resolved_database = database_input if database_input else "defaultdb"

    else:
        # Non-interactive fallback defaults
        if resolved_host is None:
            resolved_host = "localhost"
        if resolved_port is None:
            resolved_port = 26257
        if resolved_user is None:
            resolved_user = "root"
        if resolved_password is None:
            resolved_password = ""
        if resolved_database is None:
            resolved_database = "defaultdb"

    return {
        "host": resolved_host,
        "port": int(resolved_port),
        "user": resolved_user,
        "password": resolved_password,
        "database": resolved_database,
        "sslmode": resolved_sslmode,
    }


def resolve_oracle_credentials(
    host: Optional[str] = None,
    port: Optional[int] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    service_name: Optional[str] = None,
    sid: Optional[str] = None,
    database: Optional[str] = None,
    thick_mode: Optional[bool] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve Oracle Database connection credentials from arguments, env vars, or interactive prompts.

    Args:
        host: Hostname or IP.
        port: Port number.
        user: Username.
        password: Password.
        service_name: Oracle Service Name.
        sid: Oracle System Identifier.
        database: Alias for service_name/sid.
        thick_mode: Enable Oracle thick client mode.
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: host, port, user, password, service_name, sid, database, thick_mode.
    """
    env_host = os.getenv("ESJE_ORACLE_HOST") or os.getenv("ORACLE_HOST") or os.getenv("ORA_HOST")
    env_port = os.getenv("ESJE_ORACLE_PORT") or os.getenv("ORACLE_PORT") or os.getenv("ORA_PORT")
    env_user = os.getenv("ESJE_ORACLE_USER") or os.getenv("ORACLE_USER") or os.getenv("ORA_USER")
    env_password = os.getenv("ESJE_ORACLE_PASSWORD") or os.getenv("ORACLE_PASSWORD") or os.getenv("ORA_PASSWORD")
    env_service_name = os.getenv("ESJE_ORACLE_SERVICE_NAME") or os.getenv("ORACLE_SERVICE_NAME")
    env_sid = os.getenv("ESJE_ORACLE_SID") or os.getenv("ORACLE_SID")
    env_database = os.getenv("ESJE_ORACLE_DATABASE") or os.getenv("ORACLE_DATABASE") or os.getenv("ORADATABASE")
    env_thick_mode = os.getenv("ESJE_ORACLE_THICK_MODE")

    resolved_host = host if host is not None else env_host
    resolved_port = port if port is not None else (int(env_port) if env_port else None)
    resolved_user = user if user is not None else env_user
    resolved_password = password if password is not None else env_password
    resolved_service_name = service_name if service_name is not None else env_service_name
    resolved_sid = sid if sid is not None else env_sid
    resolved_database = database if database is not None else env_database

    if thick_mode is not None:
        resolved_thick_mode = thick_mode
    elif env_thick_mode is not None:
        resolved_thick_mode = env_thick_mode.lower() in ("true", "1", "yes")
    else:
        resolved_thick_mode = False

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_host is None:
            host_input = input("Host [localhost]: ").strip()
            resolved_host = host_input if host_input else "localhost"

        if resolved_port is None:
            port_input = input("Port [1521]: ").strip()
            resolved_port = int(port_input) if port_input else 1521

        if resolved_user is None:
            user_input = input("Username [system]: ").strip()
            resolved_user = user_input if user_input else "system"

        if resolved_password is None:
            resolved_password = getpass.getpass("Password: ")

        if resolved_service_name is None and resolved_sid is None and resolved_database is None:
            target_input = input("Service Name or SID [optional, e.g. XE or ORCLCDB]: ").strip()
            if target_input:
                resolved_service_name = target_input

    else:
        # Non-interactive fallback defaults
        if resolved_host is None:
            resolved_host = "localhost"
        if resolved_port is None:
            resolved_port = 1521
        if resolved_user is None:
            resolved_user = "system"
        if resolved_password is None:
            resolved_password = ""

    return {
        "host": resolved_host,
        "port": int(resolved_port),
        "user": resolved_user,
        "password": resolved_password,
        "service_name": resolved_service_name,
        "sid": resolved_sid,
        "database": resolved_database,
        "thick_mode": resolved_thick_mode,
    }


def resolve_sqlite_credentials(
    database: Optional[str] = None,
    read_only: Optional[bool] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve SQLite database path and settings from arguments, env vars, or interactive prompts.

    Args:
        database: Path to SQLite file or ':memory:'.
        read_only: Whether to open in read-only mode.
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with keys: database, read_only.
    """
    env_database = os.getenv("ESJE_SQLITE_DATABASE") or os.getenv("SQLITE_DATABASE")
    env_read_only = os.getenv("ESJE_SQLITE_READ_ONLY")

    resolved_database = database if database is not None else env_database
    if read_only is not None:
        resolved_read_only = read_only
    elif env_read_only is not None:
        resolved_read_only = env_read_only.lower() in ("true", "1", "yes")
    else:
        resolved_read_only = False

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_database is None:
            db_input = input("SQLite database path [:memory:]: ").strip()
            resolved_database = db_input if db_input else ":memory:"
    else:
        if resolved_database is None:
            resolved_database = ":memory:"

    return {
        "database": resolved_database,
        "read_only": resolved_read_only,
    }


def resolve_snowflake_credentials(
    account: Optional[str] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    database: Optional[str] = None,
    schema: Optional[str] = None,
    warehouse: Optional[str] = None,
    role: Optional[str] = None,
    authenticator: Optional[str] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve Snowflake connection credentials from arguments, env vars, or interactive prompts.

    Args:
        account: Snowflake account identifier.
        user: Username.
        password: Password.
        database: Database name.
        schema: Schema name.
        warehouse: Virtual Warehouse name.
        role: Role name.
        authenticator: Authenticator method (e.g. 'externalbrowser').
        interactive_prompt: Override interactive prompting behavior.

    Returns:
        Dict with resolved keys: account, user, password, database, schema, warehouse, role, authenticator.
    """
    env_account = os.getenv("ESJE_SNOWFLAKE_ACCOUNT") or os.getenv("SNOWFLAKE_ACCOUNT") or os.getenv("SF_ACCOUNT")
    env_user = os.getenv("ESJE_SNOWFLAKE_USER") or os.getenv("SNOWFLAKE_USER") or os.getenv("SF_USER")
    env_password = os.getenv("ESJE_SNOWFLAKE_PASSWORD") or os.getenv("SNOWFLAKE_PASSWORD") or os.getenv("SF_PASSWORD")
    env_database = os.getenv("ESJE_SNOWFLAKE_DATABASE") or os.getenv("SNOWFLAKE_DATABASE") or os.getenv("SF_DATABASE")
    env_schema = os.getenv("ESJE_SNOWFLAKE_SCHEMA") or os.getenv("SNOWFLAKE_SCHEMA") or os.getenv("SF_SCHEMA")
    env_warehouse = os.getenv("ESJE_SNOWFLAKE_WAREHOUSE") or os.getenv("SNOWFLAKE_WAREHOUSE") or os.getenv("SF_WAREHOUSE")
    env_role = os.getenv("ESJE_SNOWFLAKE_ROLE") or os.getenv("SNOWFLAKE_ROLE") or os.getenv("SF_ROLE")
    env_authenticator = os.getenv("ESJE_SNOWFLAKE_AUTHENTICATOR") or os.getenv("SNOWFLAKE_AUTHENTICATOR")

    resolved_account = account if account is not None else env_account
    resolved_user = user if user is not None else env_user
    resolved_password = password if password is not None else env_password
    resolved_database = database if database is not None else env_database
    resolved_schema = schema if schema is not None else env_schema
    resolved_warehouse = warehouse if warehouse is not None else env_warehouse
    resolved_role = role if role is not None else env_role
    resolved_authenticator = authenticator if authenticator is not None else env_authenticator

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_account is None:
            resolved_account = input("Snowflake Account (e.g. org-account): ").strip()

        if resolved_user is None:
            resolved_user = input("Username: ").strip()

        if resolved_password is None and resolved_authenticator != "externalbrowser":
            resolved_password = getpass.getpass("Password: ")

        if resolved_database is None:
            db_in = input("Database [optional]: ").strip()
            resolved_database = db_in if db_in else ""

        if resolved_warehouse is None:
            wh_in = input("Warehouse [optional]: ").strip()
            resolved_warehouse = wh_in if wh_in else ""

        if resolved_role is None:
            role_in = input("Role [optional]: ").strip()
            resolved_role = role_in if role_in else ""

    else:
        if resolved_account is None:
            resolved_account = ""
        if resolved_user is None:
            resolved_user = ""
        if resolved_password is None:
            resolved_password = ""
        if resolved_database is None:
            resolved_database = ""
        if resolved_schema is None:
            resolved_schema = "PUBLIC"
        if resolved_warehouse is None:
            resolved_warehouse = ""
        if resolved_role is None:
            resolved_role = ""
        if resolved_authenticator is None:
            resolved_authenticator = ""

    return {
        "account": resolved_account,
        "user": resolved_user,
        "password": resolved_password,
        "database": resolved_database,
        "schema": resolved_schema or "PUBLIC",
        "warehouse": resolved_warehouse,
        "role": resolved_role,
        "authenticator": resolved_authenticator or "",
    }


def resolve_databricks_credentials(
    host: Optional[str] = None,
    token: Optional[str] = None,
    http_path: Optional[str] = None,
    catalog: Optional[str] = None,
    schema: Optional[str] = None,
    port: Optional[int] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve Databricks connection credentials from arguments, env vars, or interactive prompts."""
    env_host = os.getenv("ESJE_DATABRICKS_HOST") or os.getenv("DATABRICKS_HOST") or os.getenv("DATABRICKS_SERVER_HOSTNAME")
    env_token = os.getenv("ESJE_DATABRICKS_TOKEN") or os.getenv("DATABRICKS_TOKEN")
    env_http_path = os.getenv("ESJE_DATABRICKS_HTTP_PATH") or os.getenv("DATABRICKS_HTTP_PATH")
    env_catalog = os.getenv("ESJE_DATABRICKS_CATALOG") or os.getenv("DATABRICKS_CATALOG") or os.getenv("DATABRICKS_DATABASE")
    env_schema = os.getenv("ESJE_DATABRICKS_SCHEMA") or os.getenv("DATABRICKS_SCHEMA")
    env_port = os.getenv("ESJE_DATABRICKS_PORT") or os.getenv("DATABRICKS_PORT")

    resolved_host = host if host is not None else env_host
    resolved_token = token if token is not None else env_token
    resolved_http_path = http_path if http_path is not None else env_http_path
    resolved_catalog = catalog if catalog is not None else env_catalog
    resolved_schema = schema if schema is not None else env_schema
    resolved_port = port if port is not None else (int(env_port) if env_port else None)

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_host is None:
            resolved_host = input("Databricks Hostname (e.g. adb-xxx.cloud.databricks.com): ").strip()

        if resolved_http_path is None:
            resolved_http_path = input("HTTP Path (e.g. /sql/1.0/warehouses/...): ").strip()

        if resolved_token is None:
            resolved_token = getpass.getpass("Personal Access Token: ")

        if resolved_catalog is None:
            cat_in = input("Catalog [optional]: ").strip()
            resolved_catalog = cat_in if cat_in else ""

        if resolved_schema is None:
            sch_in = input("Schema [optional]: ").strip()
            resolved_schema = sch_in if sch_in else ""

        if resolved_port is None:
            port_in = input("Port [443]: ").strip()
            resolved_port = int(port_in) if port_in else 443
    else:
        if resolved_host is None:
            resolved_host = ""
        if resolved_token is None:
            resolved_token = ""
        if resolved_http_path is None:
            resolved_http_path = ""
        if resolved_catalog is None:
            resolved_catalog = ""
        if resolved_schema is None:
            resolved_schema = ""
        if resolved_port is None:
            resolved_port = 443

    return {
        "host": resolved_host,
        "token": resolved_token,
        "http_path": resolved_http_path,
        "catalog": resolved_catalog,
        "schema": resolved_schema,
        "port": int(resolved_port),
    }


def resolve_redshift_credentials(
    host: Optional[str] = None,
    port: Optional[int] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    database: Optional[str] = None,
    sslmode: Optional[str] = None,
    interactive_prompt: Optional[bool] = None,
) -> Dict[str, Any]:
    """Resolve Amazon Redshift connection credentials from arguments, env vars, or interactive prompts."""
    env_host = os.getenv("ESJE_REDSHIFT_HOST") or os.getenv("REDSHIFT_HOST") or os.getenv("AWS_REDSHIFT_HOST")
    env_port = os.getenv("ESJE_REDSHIFT_PORT") or os.getenv("REDSHIFT_PORT") or os.getenv("AWS_REDSHIFT_PORT")
    env_user = os.getenv("ESJE_REDSHIFT_USER") or os.getenv("REDSHIFT_USER") or os.getenv("AWS_REDSHIFT_USER")
    env_password = os.getenv("ESJE_REDSHIFT_PASSWORD") or os.getenv("REDSHIFT_PASSWORD") or os.getenv("AWS_REDSHIFT_PASSWORD")
    env_database = os.getenv("ESJE_REDSHIFT_DATABASE") or os.getenv("REDSHIFT_DATABASE") or os.getenv("AWS_REDSHIFT_DATABASE")
    env_sslmode = os.getenv("ESJE_REDSHIFT_SSLMODE") or os.getenv("REDSHIFT_SSLMODE")

    resolved_host = host if host is not None else env_host
    resolved_port = port if port is not None else (int(env_port) if env_port else None)
    resolved_user = user if user is not None else env_user
    resolved_password = password if password is not None else env_password
    resolved_database = database if database is not None else env_database
    resolved_sslmode = sslmode if sslmode is not None else env_sslmode

    should_prompt = interactive_prompt if interactive_prompt is not None else is_interactive()

    if should_prompt:
        if resolved_host is None:
            host_in = input("Redshift Host [localhost]: ").strip()
            resolved_host = host_in if host_in else "localhost"

        if resolved_port is None:
            port_in = input("Port [5439]: ").strip()
            resolved_port = int(port_in) if port_in else 5439

        if resolved_user is None:
            user_in = input("Username [awsuser]: ").strip()
            resolved_user = user_in if user_in else "awsuser"

        if resolved_password is None:
            resolved_password = getpass.getpass("Password: ")

        if resolved_database is None:
            db_in = input("Database [dev]: ").strip()
            resolved_database = db_in if db_in else "dev"

    else:
        if resolved_host is None:
            resolved_host = "localhost"
        if resolved_port is None:
            resolved_port = 5439
        if resolved_user is None:
            resolved_user = "awsuser"
        if resolved_password is None:
            resolved_password = ""
        if resolved_database is None:
            resolved_database = "dev"

    return {
        "host": resolved_host,
        "port": int(resolved_port),
        "user": resolved_user,
        "password": resolved_password,
        "database": resolved_database,
        "sslmode": resolved_sslmode,
    }








